import icons from './Icon';

export {icons};
