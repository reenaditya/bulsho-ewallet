import React from 'react'

export default {
	themeColor: '#FFFFFF',
	themeColor2: '#581449',
	buttonColor: '#581449',
	linkColor: '#581449',
	textColor: '#000000',
	text2Color: '#FFFFFF',
	iconColor: '#581449',
	currency: '$'
}